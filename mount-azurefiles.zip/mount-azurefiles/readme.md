# mount-azurefiles Role
On Windows or RHEL, mounts Azure Storage Account Fileshare.

#### Required variables:
| Variable    | Description | OS |
| ----------- | ----------- | -- |
| stg_account_name | Storage account name (.file.core.windows.net suffix assumed) | RHEL/Windows |
| stg_account_key | Access key for above | RHEL/Windows |
| stg_fileshare_name | Name of existing fileshare on above | RHEL/Windows |
| mount_point | Linux mount point (ie /mnt/sharename) | RHEL |
| win_mount_letter | Windows drive letter (ie S or Z) | Windows |

#### Future:
- Should better account for private endpoint addresses and accept storage account URI rather than account name.
- Windows drive mounting not persistent for all users.
