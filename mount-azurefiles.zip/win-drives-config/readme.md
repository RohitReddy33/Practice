# win-drives-config Role
Performs the following functions on a Windows VM:
1. Expand the OS-disk to maximum capacity
2. Mount and format any unmounted data disks, assigning drive letters sequentially starting with F

#### Future:
- Will likely be placed in a common/windows role
