# azdo-poolagent Role
On both Linux and Windows, will install the Azure Pipelines agent and register it to the given organization and agent pool using PAT token.

#### Required variables:
| Variable    | Description |
| ----------- | ----------- |
| azdo_url    | AZDO organization URL       |
| azdo_pat_token   | PAT token with agent pool manage rights        |
| azdo_agent_pool   | Name of agent pool in above organization        |

#### Notes:
- AZDO agent pool must be created prior to running

#### Future:
- Once azure-devops CLI adds the ability to add agent pools this could be added to this role (create agent pool if it doesn't exist)

