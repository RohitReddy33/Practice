# script for Azure servers / Remote Power / Domain join
<#
    https://www.ryadel.com/en/windows-users-administrators-group-without-admin-rights-uac-fix/
    Important that "User Account Control: Run all administrators in Admin Approval Mode" is disabled
    Registry Hive: HKEY_LOCAL_MACHINE
    Registry Path: \Software\Microsoft\Windows\CurrentVersion\Policies\System\
    Value Name: EnableLUA
    Value Type: REG_DWORD
    Value: 1 = enabled / 0 = disabled (must be set) 
#>

# ------------------------------------------------------------------
$Scriptversion = "1.3"
# Version 1.3 - Fix static domain join to munichre.com - Domain was not added to remote script block
# ------------------------------------------------------------------
# local acount information -----------------------------------------
$User = "devopsdomainjoin"
$PWord = ConvertTo-SecureString -String "d0mJ01n#!2022" -AsPlainText -Force
$Cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, $PWord
# ------------------------------------------------------------------

# remote server ----------------------------------------------------
Write-Host "********************************************************" -ForegroundColor Blue
Write-Host "*** AD Domain Join Script (Version: $($scriptversion)) ***"
Write-Host "********************************************************" -ForegroundColor Blue
Write-Host ""
$remoteIP = Read-Host "please type the remote ip" # 10.253.32.4
# ------------------------------------------------------------------

# target defintions
# EMEA / AMERICA / ASIA
$ResourceDomain = "eu.munichre.com","am.munichre.com","as.munichre.com" | Out-GridView -Title "please select domain" -PassThru

# Usage
$Usage = "DEV", "INT", "PRD" | Out-GridView -Title "please select usage type" -PassThru

# Server Role
$Role = "Standard", "IIS", "SQL" | Out-GridView -Title "please select usage type" -PassThru


#OU path
switch ( $ResourceDomain )
{
    eu.munichre.com
    {
        $OUpath = "OU=Computers,OU=Dom-EUROPE,DC=eu,DC=munichre,DC=com"
    }
    am.munichre.com
    {
        $OUpath = "OU=Computers,OU=Dom-AMERICA,DC=am,DC=munichre,DC=com"
    }
    as.munichre.com
    {
        $OUpath = "OU=Computers,OU=Dom-ASIA,DC=as,DC=munichre,DC=com"
    }
}

switch ( $Usage )
{
    DEV
    {
        $OUpath = "OU=Servers,OU=$Usage,$OUpath"
    }
    INT
    {
        $OUpath = "OU=Servers,OU=$Usage,$OUpath"
    }
    PRD
    {
        $OUpath = "OU=Servers,OU=$Usage,$OUpath"
    }
}

switch ( $Role )
{
    Standard
    {
        $SRVRole = "OU=Standard"
    }
    IIS
    {
        $SRVRole = "OU=IIS"
    }
    SQL
    {
        $SRVRole= "OU=SQL"
    }
}



# debugging --------------------------------------------------------
<#
$cred = Get-Credential -Credential devopsdomainjoin # d0mJ01n#!2022
#>
# ------------------------------------------------------------------

# local script block (new) -----------------------------------------
$RemoteBlock={param($OU,$domain)
    Write-Host "----------------------------------------------"
    $RemoteHostname = $env:computername
    Write-Host "Remote-System: " -ForegroundColor Cyan -NoNewline
    Write-Host $global:RemoteHostname -ForegroundColor Yellow
    Write-Host "Target domain: " -ForegroundColor Cyan -NoNewline
    Write-Host $domain -ForegroundColor Yellow
    Write-Host "Target OU: " -ForegroundColor Cyan -NoNewline
    Write-Host $OU -ForegroundColor Yellow
    Write-Host "current user: " -ForegroundColor Cyan -NoNewline
    Write-Host $env:username -ForegroundColor Yellow
    Write-Host "----------------------------------------------"
    Write-Host "check (ipconfig)" -ForegroundColor Green
    $ip = ipconfig /all
    Write-Host "----------------------------------------------"
    Write-Host "check (local Admins)" -ForegroundColor Green
    $Admins = Get-LocalGroupMember -Group "Administrators"
    Write-Host "----------------------------------------------"
        Write-Host "check UAC:" -ForegroundColor Green -NoNewline
    try {
        $REG_UAC = 'HKLM:\\Software\Microsoft\Windows\CurrentVersion\Policies\System'
        $REG_Value_UAC = (Get-ItemProperty -Path $REG_UAC).EnableLUA
    
        if (($REG_Value_UAC -eq '0')) {
            #Below necessary for for Domain join
            Write-Host ' OK (UAC is disabled)' -ForegroundColor Green
        }
        else {
            Write-Host ' Error (UAC is enabled) - UAC must be disabled!' -ForegroundColor Red
            # TODO: Disable UAC via registry key
            Set-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -value "0"
            Write-Host "UAC has been temporarily disabled via registry"
            # Read-Host "Press continue for quit"
            # exit-pssession
            # exit
        }
    }
    catch {
        Write-Host 'Error (UAC is enabled)' -ForegroundColor Red
        Read-Host "Press continue for quit"
        exit-pssession
        exit
    }
    
    [PSCustomObject]@{
        RName = $RemoteHostname
        RIP = $ip
        RAdmins = $Admins.Name
    }


    Write-Host "----------------------------------------------"
    Read-Host "Press continue for domain joining"
    Write-Host "Information: system will be reboot automatically!" -ForegroundColor Yellow
    Write-Host "----------------------------------------------"
    #Write-Host "please provide your Munich AD credentials for domain joining!" -ForegroundColor Cyan
    $ADCred = get-credential -Message "your Munich AD credential please!"
    # start-sleep 5

    #$DomCred = Get-Credential -Titel "Domain Join" -Message "please provice MRE cred"
    Add-Computer -DomainName $domain -OUPath $OU -DomainCredential $ADCred
    #Add-Computer -DomainName $domain -Credential $ADCred

    Write-Host "----------------------------------------------"
    Write-Host "enable UAC again" -ForegroundColor Green
    Set-ItemProperty -path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLUA" -value "1"

    Write-Host "----------------------------------------------"
    Write-Host "delete local account: devopsdomainjoin" -ForegroundColor Green
    Remove-LocalUser -Name "devopsdomainjoin"

    Write-Host "----------------------------------------------"
    Write-Host "reboot server" -ForegroundColor Green
    restart-computer -Force

}
# ------------------------------------------------------------------

# test network connection ------------------------------------------
Write-host "---------------------------------------------"
Write-Host "connection test:"
$ports = 5985,3389
$ports | ForEach-Object {$port = $_; if (Test-NetConnection -ComputerName $remoteip -Port $port -InformationLevel Quiet -WarningAction SilentlyContinue) 
    {"Port $port is open" } 
    else {"Port $port is closed"} }
Write-host "---------------------------------------------"
Read-Host "Press enter to continue or quit with 'CRTL + C'"
# ------------------------------------------------------------------

# test winrm connection --------------------------------------------
Write-host "---------------------------------------------"
Write-Host "testing remote powershell session"
#test-wsman -computername $remoteIP -authentication default -Credential $cred
Write-host "---------------------------------------------"
if ($OS = test-wsman -computername $remoteIP -authentication default -Credential $cred) {
    Write-Host "WinRM test: OK" -ForegroundColor Green
} else {
    Write-Host "WinRM test: failed" -ForegroundColor Red
    exit
}
start-sleep 15
#$OS = test-wsman -computername $remoteIP -authentication default -Credential $cred
$OSVer = ($OS.ProductVersion).Trim("OS:")
$OSVer = $OSVer.split(".")[2].split(" ")[0]

if ($OSVer -eq "17763") { 
    Write-Host "OS Version is 2019" -ForegroundColor Yellow
    
    $targetOU = "$SRVRole,OU=MemberServers2019-DevSecOps,$OUpath"
}
elseif ($OSVer -eq "20348") {
    Write-Host "OS Version is 2022" -ForegroundColor Yellow
    
    $targetOU = "$SRVRole,OU=MemberServers2022-DevSecOps,$OUpath"
}
elseif ($OSVer -eq "14393") {
    Write-Host "OS Version is 2016" -ForegroundColor Yellow
    
    $targetOU = "$SRVRole,OU=MemberServers2016-DevSecOps,$OUpath"
}
else { 
    Write-Host "###############################################" -ForegroundColor DarkRed -BackgroundColor Black
    Write-Host " -- no OS Version available!! --" -ForegroundColor Red
    Write-Host "###############################################" -ForegroundColor DarkRed -BackgroundColor Black
    Read-Host "Press enter to exit the script"
    exit
}
# ------------------------------------------------------------------

# manual remote powershell
# Write-host "---------------------------------------------"
# Write-Host "start remote powershell session (Exit with 'exit-pssession')"
# Enter-PSSession -ComputerName $remoteIP -Credential $cred
# ------------------------------------------------------------------

# start remote connection and session
Write-host "---------------------------------------------"
Write-Host "start remote connection"
$Hostinfo = Invoke-Command -ComputerName $remoteIP -Credential $cred -ScriptBlock $RemoteBlock -ArgumentList $targetOU,$ResourceDomain -ErrorAction Stop
$Hostname = $Hostinfo.Rname


# email notification -----------------------------------------------
Write-Host "-----------------------------------------------"
Write-host "sending email" -ForegroundColor DarkYellow -BackgroundColor Black

# specify the full path of your PFX certificate
$X509Cert = Get-ChildItem -path Cert:\* -Recurse | Where-Object {$_.Subject -like '*ITServerServiceWindows.munichre.com*'}

# stop trying to send an email when no certificate is found
If ($null -eq $X509Cert) {
    Write-Host "No X509 certificate found for sending emails. No email is sent." -ForegroundColor DarkYellow -BackgroundColor Black
    Exit
}

# set TLS 1.2 protocol
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# Build SMTP properties
$smtpServer = 'munichre-com.mail.protection.outlook.com'
$smtpPort = '25'
$smtp = New-Object Net.Mail.SmtpClient($smtpServer,$smtpPort)
$smtp.ClientCertificates.Add($X509Cert)
$smtp.EnableSSL = $true

# Compose BodyMessage
$Body = "<h3>AD Domain Join Information:</h3>"
$Body += "Servername: $Hostname<br>"
$Body += "IP: $remoteIP<br>"
$Body += "TargeOU: $targetOU<br>"
$Body += "<br>"
$Body += "<h6>excecuty by: $env:username</h6>"
$Body += "<h6>Scriptversion: $Scriptversion</h6>"


# Compose message
$emailMessage = New-Object System.Net.Mail.MailMessage
$emailMessage.From = 'p0040150259@munichre.com'
$emailMessage.To.Add('rameister@munichre.com')
$emailMessage.CC.Add('NParmar@munichre.com')
$emailMessage.CC.Add('EDubey@munichre.com')
$emailMessage.Subject = "AD Domain join for Server: $Hostname"
$EmailMessage.IsBodyHtml = $true
$EmailMessage.Body = $Body

# Send the message
$smtp.Send($emailMessage) 
# ------------------------------------------------------------------

# ------------------------------------------------------------------
# END of script
# ------------------------------------------------------------------
