# azdo-test-agentpool Role
Tests validity of PAT token for given AZDO organization and existence of agent pool (this can not yet be created using AZ PIPELINES CLI) as these are necessary for IICS install to run successfully. Will fail if either test is not successful.

#### Required variables:
| Variable    | Description |
| ----------- | ----------- |
| azdo_url    | AZDO organization URL       |
| azdo_pat_token   | PAT token with agent pool manage rights        |
| azdo_agent_pool   | Name of agent pool in above organization        |

#### Notes:
- Should be run on the Ansible VM (localhost) as it uses pexpect
