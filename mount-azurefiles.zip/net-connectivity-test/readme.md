# net-connectivity-test Role
On Windows or RHEL, mounts Azure Storage Account Fileshare.

#### Required variables:
| Variable    | Description | OS |
| ----------- | ----------- | -- |
| tests | YAML list of tests (example below) | RHEL/Windows |

#### Sample "tests" variable:
```
- { address: mysqldb.database.windows.net, port: 1433 }
- { address: 10.10.1.2, port: 22 }
- { address: microsoft.com, port: 443 }
```

#### Notes:
- Currently nformational only; produces failures when connectivity does not succeed but these are ignored.